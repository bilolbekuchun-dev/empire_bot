from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import WebAppInfo
from config import BOT_URL, SUPPORT_ADMIN, CHANNEL_USERNAME, WEBAPP_URL

bot_link_markup = InlineKeyboardBuilder()
bot_link_markup.button(text="Botga o'tish", url=BOT_URL)
bot_link_markup = bot_link_markup.as_markup()


def get_start_markup(lang: str = "uz"):
    """Asosiy menyu. lang parametri eski chaqiruvlar uchun qoldirilgan — bot yagona tilda."""
    builder = InlineKeyboardBuilder()
    builder.button(text="🌐 Shaxsiy kabinet", web_app=WebAppInfo(url=WEBAPP_URL))
    builder.button(text="✅ Guruhga qo'shish", url=BOT_URL + "?startgroup=true")
    builder.button(text="🌟 Premium guruhlar", callback_data="prem_groups_start")
    builder.button(text="✍🏻 Savollar uchun", url=SUPPORT_ADMIN)
    builder.button(text="📡 Kanal", url="https://T.me/" + CHANNEL_USERNAME[1:])
    builder.adjust(1, 1, 1, 2)
    return builder.as_markup()


start_markup = get_start_markup()


def gender_keyboard(lang: str = "uz"):
    m = InlineKeyboardBuilder()
    m.button(text="👦 Yigit / Erkak", callback_data="gender_select_m")
    m.button(text="👧 Qiz / Ayol", callback_data="gender_select_f")
    m.adjust(2)
    return m.as_markup()
