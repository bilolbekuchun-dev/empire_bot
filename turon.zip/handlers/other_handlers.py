from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, PreCheckoutQuery
from aiogram.filters import Command, and_f
from filters.more import DelCommands
from utils import start, sandiqlar, profile_actions
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

router = Router()

class VipEmojiState(StatesGroup):
    waiting_for_emoji = State()

@router.message(DelCommands())
async def f(message: Message):
    pass

@router.message(profile_actions.TransferProfileState.waiting_for_transfer_profile)
async def f(message: Message, state: FSMContext):
    await profile_actions.process_transfer_profile(message=message, state=state)

@router.message(Command("vipemoji"))
@router.message(F.text.startswith("/vipemoji"))
async def f(message: Message, state: FSMContext):
    await sandiqlar.start_vip_emoji_change(message=message, state=state)

@router.message(VipEmojiState.waiting_for_emoji)
async def f(message: Message, state: FSMContext):
    await sandiqlar.process_vip_emoji_message(message=message, state=state)

@router.callback_query(F.data.startswith("open-sandiq"))
async def f(call: CallbackQuery, bot: Bot, state: FSMContext):
    await sandiqlar.open_sandiqlar(call, state)

@router.callback_query(F.data == "vip_emoji_change")
async def f(call: CallbackQuery, bot: Bot, state: FSMContext):
    await sandiqlar.start_vip_emoji_change_call(call, state)

@router.callback_query(F.data.startswith("super_sandiq"))
async def f(call: CallbackQuery, bot: Bot, state: FSMContext):
    await sandiqlar.open_super_sandiq(call, state)

@router.callback_query(F.data.startswith("mega_sandiq"))
async def f(call: CallbackQuery, bot: Bot, state: FSMContext):
    await sandiqlar.open_mega_sandiq(call, state)

@router.callback_query(F.data.startswith("back_to_start"))
async def f(call: CallbackQuery):
    await start.start_call_handler(call=call)

@router.callback_query(F.data.startswith("vip_user"))
async def f(call: CallbackQuery, state: FSMContext):
    await sandiqlar.buy_vip_user(call=call, state=state)

@router.callback_query(F.data.startswith("replace_profile"))
async def f(call: CallbackQuery, state: FSMContext):
    await profile_actions.transfer_profile(call=call, state=state)


@router.callback_query(F.data.startswith("rp_"))
async def f(call: CallbackQuery, state: FSMContext):
    await profile_actions.approve_transfer_profile(call=call, state=state)